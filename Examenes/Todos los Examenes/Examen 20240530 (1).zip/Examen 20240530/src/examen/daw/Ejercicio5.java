/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen.daw;



/**
 *
 * @author RAMONFR
 */
public class Ejercicio5 {

    private static Connection cn = Ejercicio1.getConnection();
    
    public static void ejecutar() {


    }
}
