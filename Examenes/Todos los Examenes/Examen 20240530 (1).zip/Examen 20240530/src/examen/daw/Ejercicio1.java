/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen.daw;




/**
 *
 * @author RAMONFR
 */
public class Ejercicio1 {

    private static Connection cn;


    
    public static void ejecutar() {
        
    }



    public static Connection getConnection() {
        return cn;
    }


   
}
