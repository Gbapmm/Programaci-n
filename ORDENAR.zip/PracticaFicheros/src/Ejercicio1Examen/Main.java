package Ejercicio1Examen;

import java.io.File;

public class Main {

    public static void main(String[]args) {
        File file = new File("../PracticaFicheros/Archivos");
        for(File f :file.listFiles()){
            if(f.isDirectory()){
                System.out.println(f.getName()+" -  D");
            }
            if(f.isFile()){
                System.out.println(f.getName()+" -  F");
            }
        }
    }
}
