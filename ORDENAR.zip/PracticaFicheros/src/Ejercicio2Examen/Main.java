package Ejercicio2Examen;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String line = "";
        String comparator= "";
        String palabra= "";
        int contador = 0;

        System.out.println("Introduce la palabra a buscar");
        palabra = sc.nextLine();

        try (BufferedReader br = new BufferedReader(new FileReader("../PracticaFicheros/Archivos/archivo.txt"))) {
            line = br.readLine();
            while (line != null) {
                comparator += line + " ";
                line = br.readLine();
            }

            String [] palabras = comparator.split(" ");
            for (String busqueda : palabras){
                if(busqueda.equals(palabra)){
                    contador++;
                }
            }
            System.out.println("La palabra " + palabra + " aparece " + contador + " veces.");

        } catch (Exception e){
            e.printStackTrace();
        }
    }
}