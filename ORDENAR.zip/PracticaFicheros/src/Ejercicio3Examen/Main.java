package Ejercicio3Examen;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class Main {
    public static void main(String[] args) {
        try(BufferedOutputStream br = new BufferedOutputStream(new FileOutputStream("..\\PracticaFicheros\\Archivos\\vox.JPG"));
            BufferedInputStream bi = new BufferedInputStream(new FileInputStream("..\\PracticaFicheros\\Archivos\\IMG_8313.JPG"))){
            byte [] b = bi.readAllBytes();
            br.write(b);
        }catch(IOException e){
           e.printStackTrace();
        }
    }
}
