package BufferedReader;

import java.io.FileWriter;
import java.io.BufferedWriter;

public class Main {
    public static void main(String[] args) {
        try ( BufferedWriter bw = new BufferedWriter(new FileWriter("../PracticaFicheros/Archivos/archivo.txt"))){
            bw.write("Hola, mundo!");
            bw.newLine();
            bw.write("Este es un archivo de salida.");
            bw.close();
            
            System.out.println("Archivo creado y escrito con éxit.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
