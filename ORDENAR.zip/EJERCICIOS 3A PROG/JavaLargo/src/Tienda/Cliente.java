package Tienda;

import java.time.LocalDate;

public class Cliente {
    
    private String nif;
    private String nombre;
    private Double dinero;
    private LocalDate fecha_nac;

    public Cliente(String nif, String nombre, Double dinero, LocalDate fecha_nac) {
        this.nif = nif;
        this.nombre = nombre;
        this.dinero = dinero;
        this.fecha_nac = fecha_nac;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDinero(Double dinero) {
        this.dinero = dinero;
    }

    public void setFecha_nac(LocalDate fecha_nac) {
        this.fecha_nac = fecha_nac;
    }

    public String getNif() {
        return nif;
    }

    public String getNombre() {
        return nombre;
    }

    public Double getDinero() {
        return dinero;
    }

    public LocalDate getFecha_nac() {
        return fecha_nac;
    }
    
}
