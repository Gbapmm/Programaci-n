package Tienda;

public class Empleado {
    
    private String tipo;
    private int id;
    private int stock;
    private Double precio;
    private String nombre;

    public Empleado(String tipo, int id, int stock, Double precio, String nombre) {
        this.tipo = tipo;
        this.id = id;
        this.stock = stock;
        this.precio = precio;
        this.nombre = nombre;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public int getId() {
        return id;
    }

    public int getStock() {
        return stock;
    }

    public Double getPrecio() {
        return precio;
    }

    public String getNombre() {
        return nombre;
    }
    
    
}
