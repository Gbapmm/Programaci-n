package Tienda;

import java.util.List;

public class Tienda {
    
    private String telefono;
    private String nombre;
    private String direccion;
    private String jefe;
    private String cif;
    private List<Empleado> empleados;
    private double dinero;

    public Tienda(String telefono, String nombre, String direccion, String jefe, String cif, List<Empleado> empleados, double dinero) {
        this.telefono = telefono;
        this.nombre = nombre;
        this.direccion = direccion;
        this.jefe = jefe;
        this.cif = cif;
        this.empleados = empleados;
        this.dinero = dinero;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDirección(String Dirección) {
        this.direccion = direccion;
    }

    public void setJefe(String jefe) {
        this.jefe = jefe;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public void setEmpleados(List<Empleado> empleados) {
        this.empleados = empleados;
    }

    public void setDinero(double dinero) {
        this.dinero = dinero;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getJefe() {
        return jefe;
    }

    public String getCif() {
        return cif;
    }

    public List<Empleado> getEmpleados() {
        return empleados;
    }

    public double getDinero() {
        return dinero;
    }
    
    
}
