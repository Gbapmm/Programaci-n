package Tienda;

public class Productos {
    
    private String telefono;
    private String nombre;
    private String Dirección;
    private String cif;
    private Double dinero;

    public Productos(String telefono, String nombre, String Dirección, String cif, Double dinero) {
        this.telefono = telefono;
        this.nombre = nombre;
        this.Dirección = Dirección;
        this.cif = cif;
        this.dinero = dinero;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDirección(String Dirección) {
        this.Dirección = Dirección;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public void setDinero(Double dinero) {
        this.dinero = dinero;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDirección() {
        return Dirección;
    }

    public String getCif() {
        return cif;
    }

    public Double getDinero() {
        return dinero;
    }

    
}
