package bd7;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class BD7 {

    public static void main(String[] args) {
        String url, user, password;
        url = "jdbc:postgresql://172.21.29.50:5432/super";
        user = "userDAW";
        password = "Java";
        Connection connectionPg = null;
        String pgUser = "userDAW";
        String pgPass = "Java";
        String pgDriver = "org.postgresql.Driver";
        String pgUrl = "jdbc:postgresql://172.21.29.50:5432/super";
 try {
            //Se crea la conexion con el connection
            connectionPg = DriverManager.getConnection(url, user, password);
            //Se crea un Statement de SQL mediante la conexion
            Statement stmt = connectionPg.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            //Se asigna a ResultSet el resultado del SELECT FROM actor
            ResultSet rs = stmt.executeQuery("SELECT nombre, apellido FROM clientes");

            for (String columnName : new String[]{"nombre"}) {
                while (rs.next()) {
                    String value = rs.getString(columnName);
                    System.out.println(value);
                }
                rs.beforeFirst();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}