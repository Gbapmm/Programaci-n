package bd8;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class BD8 {

    public static void main(String[] args) {
        String url, user, password;
        url = "jdbc:postgresql://172.21.29.50:5432/super";
        user = "userDAW";
        password = "Java";
        Connection connectionPg = null;
        String pgUser = "userDAW";
        String pgPass = "Java";
        String pgDriver = "org.postgresql.Driver";
        String pgUrl = "jdbc:postgresql://172.21.29.50:5432/super";

        try {
            //Se crea la conexion con el connection
            connectionPg = DriverManager.getConnection(url, user, password);
            //Desactivar auto-commit
            connectionPg.setAutoCommit(false);
            //Se crea un Statement de SQL mediante la conexion
            Statement stmt = connectionPg.createStatement();

            //Eliminar datos
            for (int i = 1; i <= 5; i++) {
                stmt.executeUpdate("DELETE FROM clientes WHERE nombre = 'Niño" + i + "'");
            }

            //Hacer commit de la transacción
            connectionPg.commit();

        } catch (SQLException e) {
            e.printStackTrace();
            if (connectionPg != null) {
                try {
                    //Hacer rollback de la transacción en caso de error
                    System.err.print("Transaction is being rolled back");
                    connectionPg.rollback();
                } catch(SQLException excep) {
                    excep.printStackTrace();
                }
            }
        } finally {
            try {
                if (connectionPg != null) {
                    connectionPg.setAutoCommit(true);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}